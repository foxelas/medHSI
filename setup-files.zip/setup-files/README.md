Instructions for MATLAB

1. Open MATLAB

2. Install necessary dependencies
   Run script 'setup_matlab.m'

3. (Optional) Move demo folder outside medHSI folder
   Add demo folder to matlab path
   Replace conf/config.ini with setup/demos/config.ini

4. Run script 'demo_init.m'
